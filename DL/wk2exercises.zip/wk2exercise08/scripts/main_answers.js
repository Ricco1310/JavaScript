var introduction = document.getElementById("introduction");

console.log(introduction.innerHTML); // 1
//console.log(introduction.innerHTML.length); // 2
//console.log(introduction.innerHTML.split(' ').length); // 3

//var paragraphs = document.getElementsByTagName('p');
//console.log(paragraphs.length); 		// 4

//var artists = document.getElementsByClassName('artist');
//console.log(artists.length); // 5

//var electric = document.getElementById('Electric');
//var electricArtists = electric.getElementsByClassName('artist');
//console.log(electricArtists.length); //6

//var paragraph9 = document.getElementsByTagName('p')[9];
//console.log(paragraph16.className); //7

//var links = document.getElementsByTagName('a');
//console.log(links[0].getAttribute('href')); //8

//var links = document.getElementsByTagName('a');
//for(var i=0; i<links.length; i++){
//	console.log(links[i].getAttribute('href'));
//} //9