

var wardrobe = [];
wardrobe[0] = 'shirts';
wardrobe[1] = 'sweaters';
wardrobe[2] = 'pants';
wardrobe[3] = 'socks';

console.log(wardrobe);
alert(wardrobe.length);


/*
var wardrobe = new Array();
wardrobe[0] = 'shirts';
wardrobe[1] = 'sweaters';
wardrobe[2] = 'pants';
wardrobe[3] = 'socks';
*/

/*
var wardrobe = new Array('shirts', 'sweater', 'pants', 'socks' );
*/

/*
var wardrobe = ['shirts', 'sweater', 'pants', 'socks'];
*/
