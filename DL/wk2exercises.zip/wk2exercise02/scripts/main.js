
var grades = [4, 8, 10, 5, 7];
var total = 0;

for(var i = 0; i < grades.length; i++){
	total += grades[i];
}

alert(total/grades.length);